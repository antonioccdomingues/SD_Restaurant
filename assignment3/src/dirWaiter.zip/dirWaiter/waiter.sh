java -classpath "../genclass.jar:."\
     clientSide.main.WaiterMain l040101-ws09.ua.pt 22340