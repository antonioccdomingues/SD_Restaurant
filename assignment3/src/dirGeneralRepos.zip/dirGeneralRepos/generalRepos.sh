java -classpath "../genclass.jar:."\
     -Djava.security.policy=java.policy\
     serverSide.main.GeneralReposMain 22345 l040101-ws09.ua.pt 22340