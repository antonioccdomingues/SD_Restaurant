java -classpath "../genclass.jar:."\
     -Djava.security.policy=java.policy\
     serverSide.main.TableMain 22343 l040101-ws09.ua.pt 22340