/**
 *  Interfaces to remote objects for the Problem of the Restaurant.
 *
 *    Communication is based on Java RMI.
 */


package interfaces;
