java -classpath "../genclass.jar:."\
     clientSide.main.StudentMain l040101-ws09.ua.pt 22340