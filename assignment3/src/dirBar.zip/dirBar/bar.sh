java -classpath "../genclass.jar:."\
     -Djava.security.policy=java.policy\
     serverSide.main.BarMain 22341 l040101-ws09.ua.pt 22340