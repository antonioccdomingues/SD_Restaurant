java -classpath "../genclass.jar:."\
     clientSide.main.ChefMain l040101-ws09.ua.pt 22340